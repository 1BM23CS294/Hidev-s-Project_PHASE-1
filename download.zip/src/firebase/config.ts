export const firebaseConfig = {
  "projectId": "studio-3425626014-bf5d2",
  "appId": "1:575624716040:web:e360ed91244116e6bcd6bd",
  "apiKey": "AIzaSyC1fAw-PR7eJUCzUkoKxAeA6hYOItpSGFU",
  "authDomain": "studio-3425626014-bf5d2.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "575624716040"
};
