'use client';

import { AuthForm } from '@/components/auth/auth-form';

export default function SignUpPage() {
  return <AuthForm mode="signup" />;
}
