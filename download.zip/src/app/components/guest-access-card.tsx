'use client';

export function GuestAccessCard() {
  return null;
}
